import 'package:flutter/material.dart';
import 'games_data.dart';


class GameDetailPage extends StatelessWidget {
  final game;

  GameDetailPage({required this.game});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(game.title),
        actions: [
          IconButton(
            icon: Icon(Icons.favorite),
            onPressed: () {
              // Implement favorite functionality
            },
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Image.network(game.cover),
            SizedBox(height: 16.0),
            Text(
              game.title,
              style: TextStyle(fontSize: 24.0, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 8.0),
            Text(game.description),
            SizedBox(height: 8.0),
            Text("Genre: ${game.genre}"),
            SizedBox(height: 8.0),
            Text("Release Date: ${game.releaseDate}"),
            SizedBox(height: 8.0),
            Text("Reviews: ${game.reviews}"),
            SizedBox(height: 16.0),
          
          ],
        ),
      ),
    );
  }
}
